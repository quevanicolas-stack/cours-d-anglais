# Fluent & Forward — supports de cours

Supports de présentation du programme Business English Accelerator.

## Contenu

| Fichier | Rôle |
|---|---|
| `module1-seance1.html` | Module 1, Séance 1 — 15 slides |
| `module1-seance2.html` | Module 1, Séance 2 — 14 slides |

Le HTML est la source unique. On le modifie, on le remplace, il n'y a pas
d'export intermédiaire.

## Récupération en début de session

```
curl https://raw.githubusercontent.com/quevanicolas-stack/cours-d-anglais/main/module1-seance1.html
```

## Repères dans le fichier

- Couleurs : bloc `:root` en haut du CSS
- Un slide = une balise `<section class="slide">`, classe `dark` pour fond vert
- Numérotation automatique
- Slide 06 : chronomètres, durée dans `data-sec` (en secondes)
- Slide 09 : lien vidéo externe, attribut `href` de `.ytcard`
- Slide 02 (séance 1) : emplacement vidéo encore vide
- Séance 2 : gabarits `.pillar-split`, `.trio`, `.vs-tall`
