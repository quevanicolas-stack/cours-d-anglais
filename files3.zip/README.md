# Fluent & Forward — supports de cours

Supports de présentation du programme Business English Accelerator.

## Contenu

| Fichier | Séance | Slides |
|---|---|---|
| `module1-seance1.html` | Why Your Brain Freezes in English | 15 |
| `module1-seance2.html` | The 3 Pillars of Business English | 14 |
| `module1-seance3.html` | Structuring Simple Professional Sentences | 16 |

Le HTML est la source unique. On le modifie, on le remplace, il n'y a pas
d'export intermédiaire.

## Récupération en début de session

```
curl https://raw.githubusercontent.com/quevanicolas-stack/cours-d-anglais/main/module1-seance1.html
```

## Repères dans le fichier

- Couleurs : bloc `:root` en haut du CSS
- Un slide = une balise `<section class="slide">`, classe `dark` pour fond vert
- Numérotation automatique
- Chronomètres : `<button class="timer" data-sec="60">`
- Lien vidéo externe : attribut `href` de `.ytcard`
- Gabarits : `.pillar-split`, `.trio`, `.vs-tall`, `.pairs`, `.wtable`, `.formula`, `.exo-right`
