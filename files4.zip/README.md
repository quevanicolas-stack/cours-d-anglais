# Fluent & Forward — supports de cours

Supports de présentation du programme Business English Accelerator.

## Contenu

| Fichier | Séance | Slides |
|---|---|---|
| `module1-seance1.html` | Why Your Brain Freezes in English | 15 |
| `module1-seance2.html` | The 3 Pillars of Business English | 16 |
| `module1-seance3.html` | Structuring Simple Professional Sentences | 16 |

Le HTML est la source unique. On le modifie, on le remplace, il n'y a pas
d'export intermédiaire.

## Récupération en début de session

```
curl https://raw.githubusercontent.com/quevanicolas-stack/cours-d-anglais/main/module1-seance1.html
```

## Repères dans le fichier

- Couleurs : bloc `:root` en haut du CSS
- Un slide = une balise `<section class="slide">`, classe `dark` pour fond vert
- Numérotation automatique
- Chronomètres : `<button class="timer" data-sec="60">`
- Lien vidéo externe : attribut `href` de `.ytcard`
- Gabarits : `.pillar-split`, `.trio`, `.vs-tall`, `.pairs`, `.wtable`, `.formula`, `.exo-right`

## Convention de couverture

Le visuel décoratif de la page 1 (cercles concentriques, en haut à droite)
compte le numéro de la séance : **un tiret arrondi par séance**, centré sur
`cx=203`, hauteur 28, `rx=6`, écart 12.

| Séance | Tirets |
|---|---|
| 1 | `x=176 w=54` vert |
| 2 | `x=150 w=54` vert · `x=216 w=40` or |
| 3 | `x=118 w=54` vert · `x=184 w=40` or · `x=236 w=52` vert |

Alternance vert `#1B6B4A` / or `#C9A96E` en partant du vert. Chaque séance
reprend les tirets de la précédente et en ajoute un, l'ensemble restant
centré. Cette convention vaut pour tous les modules.

## Icônes

Silhouettes dessinées en géométrie simple ou jeu Lucide (licence ISC, usage
commercial autorisé sans attribution). viewBox 24, `stroke-width` 1.9.
